"use strict";

/* Website Produced by Codigo |  gocodigo.com */
var KioskInstance = new Kiosk({ project_name: "Codigo Kiosk" });
KioskInstance.init();

$(function () {
    FastClick.attach(document.body);
});