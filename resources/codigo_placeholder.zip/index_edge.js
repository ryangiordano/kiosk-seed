/**
 * Adobe Edge: symbol definitions
 */
(function($, Edge, compId){
//images folder
var im='images/';

var fonts = {};    fonts['Ubuntu, sans-serif']='<link href=\'http://fonts.googleapis.com/css?family=Ubuntu:400,300,700,500\' rel=\'stylesheet\' type=\'text/css\'>';

var opts = {};
var resources = [
];
var symbols = {
"stage": {
    version: "3.0.0",
    minimumCompatibleVersion: "3.0.0",
    build: "3.0.0.322",
    baseState: "Base State",
    scaleToFit: "none",
    centerStage: "none",
    initialState: "Base State",
    gpuAccelerate: false,
    resizeInstances: false,
    content: {
            dom: [
            {
                id: 'Line2',
                type: 'group',
                rect: ['110', '325','803','166','auto', 'auto'],
                c: [
                {
                    id: 'line2',
                    type: 'text',
                    rect: ['0px', '0px','auto','auto','auto', 'auto'],
                    text: "coming soon.",
                    align: "left",
                    font: ['Ubuntu, sans-serif', 140, "rgba(165,197,75,1.00)", "500", "none", "italic"]
                }]
            },
            {
                id: 'Rule',
                type: 'group',
                rect: ['-41', '332','958','3','auto', 'auto'],
                c: [
                {
                    id: 'hr',
                    type: 'rect',
                    rect: ['0px', '0px','958px','3px','auto', 'auto'],
                    fill: ["rgba(138,138,138,1.00)"],
                    stroke: [0,"rgba(0,0,0,1)","none"]
                }]
            },
            {
                id: 'Line1',
                type: 'group',
                rect: ['362', '217','561','95','auto', 'auto'],
                c: [
                {
                    id: 'line1',
                    type: 'text',
                    rect: ['17px', '0px','641px','auto','auto', 'auto'],
                    text: "your new kiosk is",
                    align: "left",
                    font: ['Ubuntu, sans-serif', 78, "rgba(255,255,255,1.00)", "300", "none", "italic"]
                }]
            },
            {
                id: 'Logo',
                type: 'group',
                rect: ['-94', '104','1171','462','auto', 'auto'],
                c: [
                {
                    id: 'Logo_Reversed150',
                    type: 'image',
                    rect: ['0px', '0px','1171px','462px','auto', 'auto'],
                    fill: ["rgba(0,0,0,0)",im+"Logo_Reversed150.png",'0px','0px']
                }]
            },
            {
                id: 'FADE',
                type: 'rect',
                rect: ['0px', '0px','1024px','724px','auto', 'auto'],
                fill: ["rgba(0,0,0,1.00)"],
                stroke: [0,"rgb(0, 0, 0)","none"]
            }],
            symbolInstances: [

            ]
        },
    states: {
        "Base State": {
            "${_Rule}": [
                ["style", "top", '268px'],
                ["style", "left", '-992px']
            ],
            "${_Line1}": [
                ["style", "top", '179px'],
                ["style", "left", '-622px']
            ],
            "${_FADE}": [
                ["color", "background-color", 'rgba(0,0,0,1.00)'],
                ["style", "opacity", '1']
            ],
            "${_hr}": [
                ["style", "top", '0px'],
                ["color", "background-color", 'rgba(138,138,138,1.00)'],
                ["style", "left", '0px'],
                ["style", "width", '958px']
            ],
            "${_line2}": [
                ["style", "top", '0px'],
                ["color", "color", 'rgba(165,197,75,1.00)'],
                ["style", "font-weight", '500'],
                ["style", "left", '0px'],
                ["style", "font-size", '140px']
            ],
            "${_Logo}": [
                ["style", "top", '127px'],
                ["transform", "scaleY", '1.42207'],
                ["transform", "scaleX", '1.42207'],
                ["style", "left", '-650px']
            ],
            "${_Line2}": [
                ["style", "top", '161px'],
                ["subproperty", "filter.blur", '0px'],
                ["style", "opacity", '0.000000'],
                ["style", "left", '90px']
            ],
            "${_Stage}": [
                ["color", "background-color", 'rgba(54,54,54,1.00)'],
                ["style", "width", '1024px'],
                ["style", "height", '724px'],
                ["style", "overflow", 'hidden']
            ],
            "${_line1}": [
                ["color", "color", 'rgba(255,255,255,1.00)'],
                ["style", "font-weight", '300'],
                ["style", "left", '17px'],
                ["style", "font-size", '78px'],
                ["style", "top", '0px'],
                ["style", "text-align", 'left'],
                ["style", "font-style", 'italic'],
                ["style", "font-family", 'Ubuntu, sans-serif'],
                ["style", "width", '641px']
            ],
            "${_Logo_Reversed150}": [
                ["style", "left", '0px'],
                ["style", "top", '0px']
            ]
        }
    },
    timelines: {
        "Default Timeline": {
            fromState: "Base State",
            toState: "",
            duration: 1925,
            autoPlay: true,
            timeline: [
                { id: "eid126", tween: [ "style", "${_Logo}", "top", '377px', { fromValue: '127px'}], position: 0, duration: 1675, easing: "easeInOutQuad" },
                { id: "eid120", tween: [ "style", "${_Line2}", "left", '87px', { fromValue: '90px'}], position: 0, duration: 0, easing: "easeInOutQuad" },
                { id: "eid124", tween: [ "transform", "${_Logo}", "scaleY", '0.21264', { fromValue: '1.42207'}], position: 0, duration: 1675, easing: "easeInOutQuad" },
                { id: "eid112", tween: [ "style", "${_Line2}", "top", '272px', { fromValue: '161px'}], position: 1250, duration: 675, easing: "easeInOutQuad" },
                { id: "eid125", tween: [ "style", "${_Logo}", "left", '-86px', { fromValue: '-650px'}], position: 0, duration: 1675, easing: "easeInOutQuad" },
                { id: "eid109", tween: [ "style", "${_Line2}", "opacity", '1', { fromValue: '0.000000'}], position: 1250, duration: 675, easing: "easeInOutQuad" },
                { id: "eid131", tween: [ "style", "${_Rule}", "top", '268px', { fromValue: '268px'}], position: 0, duration: 0, easing: "easeInOutQuad" },
                { id: "eid105", tween: [ "style", "${_Line1}", "left", '326px', { fromValue: '-622px'}], position: 825, duration: 850, easing: "easeInOutQuad" },
                { id: "eid106", tween: [ "style", "${_Rule}", "left", '-35px', { fromValue: '-992px'}], position: 1075, duration: 850, easing: "easeInOutQuad" },
                { id: "eid127", tween: [ "style", "${_Line1}", "top", '167px', { fromValue: '179px'}], position: 0, duration: 0, easing: "easeInOutQuad" },
                { id: "eid102", tween: [ "style", "${_Line1}", "top", '167px', { fromValue: '167px'}], position: 1675, duration: 0, easing: "easeInOutQuad" },
                { id: "eid69", tween: [ "style", "${_FADE}", "opacity", '0', { fromValue: '1'}], position: 0, duration: 750, easing: "easeInOutQuad" },
                { id: "eid123", tween: [ "transform", "${_Logo}", "scaleX", '0.21264', { fromValue: '1.42207'}], position: 0, duration: 1675, easing: "easeInOutQuad" }            ]
        }
    }
}
};


Edge.registerCompositionDefn(compId, symbols, fonts, resources, opts);

/**
 * Adobe Edge DOM Ready Event Handler
 */
$(window).ready(function() {
     Edge.launchComposition(compId);
});
})(jQuery, AdobeEdge, "EDGE-15017656");
